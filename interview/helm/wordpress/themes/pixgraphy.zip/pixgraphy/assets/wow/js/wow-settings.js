jQuery( function() {
	
	// For Wow Effect
	wow = new WOW({
		boxClass: 'pixgraphy-animation'
		});
	wow.init();

} );